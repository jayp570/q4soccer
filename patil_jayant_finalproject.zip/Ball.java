import java.io.Serializable;

public class Ball implements Serializable {

    private Vector2 pos;
    private Vector2 vel = new Vector2(0, 0);
    private Vector2 acc = new Vector2(0, 0);

    private final double FRICTION = -0.1;

    private int radius = 10;
    
    public Ball(Vector2 pos) {
        this.pos = pos;
    }

    public void update() {
        acc = Vector2.add(acc, Vector2.multiply(vel, FRICTION));
        vel = Vector2.add(vel, acc);
        pos = Vector2.add(pos, vel);

        //check if out of bounds
        if(pos.getX() < radius || pos.getX() > 500-(radius)) {
            if(pos.getX() < radius) {
                pos.setX(radius);
            } else {
                pos.setX(500-(radius));
            }
            vel.set(vel.getX()*-1.1, vel.getY());
        }
        if(pos.getY() < radius || pos.getY() > 700-(radius)) {
            if(pos.getY() < radius) {
                pos.setY(radius);
            } else {
                pos.setY(700-(radius));
            }
            vel.set(vel.getX(), vel.getY()*-1.1);
        }
        //System.out.println(pos);
        acc = new Vector2(0, 0);
    }

    public void setVel(Vector2 v) {
        this.vel = v;
    }

    public void setPos(Vector2 p) {
        this.pos = p;
    }

    public int getRadius() {
        return radius;
    }

    public Vector2 getPos() {
        return pos;
    }

    public Vector2 getVel() {
        return vel;
    }

}
