2 sound effects - goal.wav: guys says goal whenever a goal is made, cheer.wav: cheering when game ends

if server does not start or there is connection issue, restart server and run client again