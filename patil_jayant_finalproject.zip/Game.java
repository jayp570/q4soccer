import java.io.Serializable;

public class Game implements Serializable {

    private DLList<Player> players = new DLList<Player>();
    private Ball ball = new Ball(new Vector2(250, 350));

    private int points1;
    private int points2;
    private boolean goal;

    private int frame = 0;
    private double timeLimit = 5*60*30;

    private int winGoals = 5;

    private String winner = "";

    private int gameWidth = 500;
    private int gameHeight = 700;
    
    public Game() {
        
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public void update() {

        goal = false;

        for(int i = 0; i < players.size(); i++) {
            players.get(i).update();
        }
        ball.update();

        //collisions
        for(int i = 0; i < players.size(); i++) {
            Player player = players.get(i);
            if(player.checkCollision(ball)) {
                Vector2 playerVel = player.getVel();
                if((int)playerVel.getX() == 0 && (int)playerVel.getY() == 0) {
                    ball.setVel(ball.getVel().oppositeVector());
                } else {
                    ball.setVel(Vector2.add(ball.getVel(), player.getVel()));
                }
            }
        }

        if(winner.equals("") && (points1 < winGoals && points2 < winGoals)) {
            //check if goal
            double ballX = ball.getPos().getX();
            double ballY = ball.getPos().getY();
            if(ballX-ball.getRadius() > 150 && ballX+ball.getRadius() < 350) {
                if(ballY+ball.getRadius() < 75) {
                    points1++;
                    ball.setPos(new Vector2(gameWidth*0.5, gameHeight*0.5));
                    ball.setVel(new Vector2(0, 0));
                    goal = true;
                } else if(ballY-ball.getRadius() > 625) {
                    points2++;
                    ball.setPos(new Vector2(gameWidth*0.5, gameHeight*0.5));
                    ball.setVel(new Vector2(0, 0));
                    goal = true;
                }
            }
        } else {
            if(points1 < points2) {
                winner = "red";
            } else if(points1 > points2) {
                winner = "blue";
            }
        }

        frame++;
    }

    public DLList<Player> getPlayers() {
        return players;
    }

    public Ball getBall() {
        return ball;
    }

    public Player getPlayer(String id) {
        for(int i = 0; i < players.size(); i++) {
            if(players.get(i).id().equals(id)) {
                return players.get(i);
            }
        }
        return null;
    }

    public int getPoints1() {
        return points1;
    }

    public int getPoints2() {
        return points2;
    }

    public String getWinner() {
        return winner;
    }

    public int getWinGoals() {
        return winGoals;
    }

    public boolean getGoal() {
        return goal;
    }

}