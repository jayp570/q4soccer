import javax.swing.JFrame;
import java.io.*;

public class Client {

    public static void main(String args[]) throws Exception {

		JFrame frame = new JFrame("Soccer");

		ClientScreen sc;
        if(args.length != 0) {
            sc = new ClientScreen(args[0]);
        } else {
            sc = new ClientScreen("localhost");
        }
		frame.add(sc);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);

		sc.poll();
    }
}
