import java.io.Serializable;

public class Node < E > implements Serializable {

    private E data;
    private Node < E > next;
    private Node < E > prev;

    public Node(E e) {
        data = e;
        next = null;
        prev = null;
    }

    public E get() {
        return data;
    }

    public Node < E > next() {
        return next;
    }

    public Node < E > prev() {
        return prev;
    }

    public void setNext(Node < E > e) {
        next = e;
    }

    public void setPrev(Node < E > e) {
        prev = e;
    }

    public void setData(E data) {
        this.data = data;
    }

    public String toString() {
        if (data != null) {
            return data.toString();
        }
        return null;
    }
}
