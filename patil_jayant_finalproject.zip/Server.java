import java.io.*;
import java.net.*;

public class Server {

    private static Manager manager;
    private static ServerSocket serverSocket;
    private static int portNumber = 1904;

    public static void main(String[] args) throws IOException {
        try {
            serverSocket = new ServerSocket(portNumber);
        } catch (IOException e) {
            System.out.println("IO Exception - server start");
        }
        manager = new Manager();
        Thread updateThread = new Thread(new UpdateThread(manager));
        updateThread.start();
        System.out.println("Server running");
        try {
            while (true) {
                poll();
            }
        } catch (IOException e) {
            System.out.println("IO Exception - server poll");
            System.exit(1);
        }
    }

    public Server() {

    }

    public static void poll() throws IOException {
        if (serverSocket == null) {
            System.out.println("bruh");
        }
        Socket clientSocket = serverSocket.accept();
        System.out.println("Connected");
        manager.add(clientSocket);
    }
}