import java.io.Serializable;

public class Vector2 implements Serializable {

    private double x;
    private double y;
    
    public Vector2(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public static Vector2 add(Vector2 a, Vector2 b) {
        return new Vector2(a.getX()+b.getX(), a.getY()+b.getY());
    }

    public static Vector2 multiply(Vector2 a, double b) {
        return new Vector2(a.getX()*b, a.getY()*b);
    }

    public Vector2 unitVector() {
        double magnitude = magnitude();
        return new Vector2(x/magnitude, y/magnitude);
    }

    public Vector2 oppositeVector() {
        return new Vector2(x*-1, y*-1);
    }

    public double getX() {
        return x;
    }

    public void setX(double num) {
        x = num;
    }

    public double getY() {
        return y;
    }

    public void setY(double num) {
        y = num;
    }

    public double magnitude() {
        return Math.sqrt((x*x) + (y*y));
    }

    public static Vector2 round(Vector2 v, int decimals) {
        double newX = Math.floor(v.getX()*Math.pow(10, decimals))/Math.pow(10, decimals);
        double newY = Math.floor(v.getY()*Math.pow(10, decimals))/Math.pow(10, decimals);
        return new Vector2(newX, newY);
    }

    public static double distance(Vector2 a, Vector2 b) {
        return Math.hypot(a.getX()-b.getX(), a.getY()-b.getY());
    }

    public void set(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public String toString() {
        return "(x: "+x+", y: "+y+")";
    }

}
