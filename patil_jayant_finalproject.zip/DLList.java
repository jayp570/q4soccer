import java.io.Serializable;

public class DLList < E > implements Serializable {

    private Node < E > head;
    private Node < E > tail;
    private int size;

    public DLList() {
        size = 0;
        head = new Node < E > (null);
        tail = new Node < E > (null);
        tail.setPrev(head);
        head.setNext(tail);
    }

    public Node < E > getNode(int index) {
        Node < E > current = head.next();
        int count = 0;
        while (current.next().next() != null) {
            if (index == count) {
                return current;
            }
            current = current.next();
            count++;
        }
        if (index == count) {
            return current;
        }
        return null;
    }

    public void add(E data) {
        Node < E > temp = new Node < E > (data);
        temp.setPrev(tail.prev());
        tail.prev().setNext(temp);
        temp.setNext(tail);
        tail.setPrev(temp);
        size++;
    }

    public void add(int index, E data) {
        Node < E > current = head;
        int count = 0;
        while (current.next() != null) {
            if (index == count) {
                Node < E > node = new Node < E > (data);
                node.setPrev(current);
                node.setNext(current.next());
                current.setNext(node);
                current.next().next().setPrev(node);
                size++;
                break;
            }
            current = current.next();
            count++;
        }
    }

    public E get(int index) {
        return getNode(index).get();
    }

    public int size() {
        return size;
    }

    public String toString() {
        if(size > 0) {
            String s = "[";
            Node < E > current = head;
            int count = 1;
            current = head.next();
            while (current.next().next() != null) {
                s = s + current.toString() + ", ";
                current = current.next();
            }
            s = s + current.toString() + "]";
            return s;
        } else {
            return "empty";
        }
        
    }

    public void remove(int n) {
        int count = 0;
        Node < E > current = head;
        current = current.next();

        while (current.next() != null) {
            if (count == n) {
                current.next().setPrev(current.prev());
                current.prev().setNext(current.next());
                size--;
            }
            current = current.next();
            count++;
        }
        if (count == n) {
            if(current.next() != null) {
                current.next().setPrev(current.prev());
                current.prev().setNext(current.next());
                size--;
            } else {
                size = 0;
                head = new Node < E > (null);
                tail = new Node < E > (null);
                tail.setPrev(head);
                head.setNext(tail);
            }
        }
    }

    public void remove(E e) {
        Node<E> current = head.next();

        while(current.next().next() != null) {
            if(current.get().equals(e)) {
                current.prev().setNext(current.next());
                current.next().setPrev(current.prev());
                size--;
            }
            current = current.next();
        }
        if(current.get().equals(e)) {
            current.prev().setNext(current.next());
            current.next().setPrev(current.prev());
            size--;
        }
    }

    public void set(int index, E data) {
        Node < E > current = head.next();
        int count = 0;
        while (current.next().next() != null) {
            if (index == count) {
                current.setData(data);
            }
            current = current.next();
            count++;
        }
        if(index == count) {
            current.setData(data);
        }
    }

    public boolean contains(E data) {
        if(size == 0) {
            return false;
        }
        Node<E> current = head.next();
        while(current.next().next() != null) {
            if(current.get().equals(data)) {
                return true;
            }
            current = current.next();
        }
        if(current.get().equals(data)) {
            return true;
        }
        return false;
    }

}
