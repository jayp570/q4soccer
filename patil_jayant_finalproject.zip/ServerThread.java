import java.io.*;
import java.net.*;
import java.util.*;

public class ServerThread implements Runnable {

    private Socket socket;
    private Manager manager;
    private ObjectOutputStream out;
    private PrintWriter outString;
    private String id;

    public ServerThread(Manager m, Socket s, String id) {
        manager = m;
        socket = s;
        this.id = id;
    }

    public void updateGame(Game g) {
        // System.out.println("thread update: "+g.getPlayers().get(0).getPos());
        // System.out.println("updating game");
        try {
            out.reset();
            out.flush();
            out.writeObject(g);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        try {
            out = new ObjectOutputStream(socket.getOutputStream());
            outString = new PrintWriter(socket.getOutputStream(), true);
            outString.println(id);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            System.out.println("Thread start");

            while (true) {
                try {
                    String message = in.readLine();
                    String id = message.substring(0, 8);
                    String command = message.substring(8);
                    Game game = manager.getGame();
                    //search through game - find player with id - update movement
                    if(command.equals("press-w")) {
                        game.getPlayer(id).addDirection("up");
                    }
                    if(command.equals("press-s")) {
                        game.getPlayer(id).addDirection("down");
                    }
                    if(command.equals("press-a")) {
                        game.getPlayer(id).addDirection("left");
                    }
                    if(command.equals("press-d")) {
                        game.getPlayer(id).addDirection("right");
                    }
                    if(command.equals("release-w")) {
                        game.getPlayer(id).removeDirection("up");
                    }
                    if(command.equals("release-s")) {
                        game.getPlayer(id).removeDirection("down");
                    }
                    if(command.equals("release-a")) {
                        game.getPlayer(id).removeDirection("left");
                    }
                    if(command.equals("release-d")) {
                        game.getPlayer(id).removeDirection("right");
                    }
                    manager.setGame(game);
                    //manager.updateClients();
                } catch(Exception e) {

                }
            }

            // out.flush();
            // out.close();
        } catch (IOException ex) {
            System.out.println("Error listening for a connection");
            System.out.println(ex.getMessage());
        }
    }

    public void setClientId() {

    }
}