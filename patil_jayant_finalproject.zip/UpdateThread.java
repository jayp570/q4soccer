public class UpdateThread extends Thread {

    Manager manager;

    int fps = 60;
    int tick = 1000/fps;
    
    public UpdateThread(Manager m) {
        manager = m;
    }

    public void run() {
        while(true) {
            manager.doGameUpdate();
            manager.updateClients();
            try {
                Thread.sleep(tick);
            } catch (Exception e) {
                Thread.currentThread().interrupt();
            }
        }
    }
    
}
