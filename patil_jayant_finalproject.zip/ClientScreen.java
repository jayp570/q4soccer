import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class ClientScreen extends JPanel implements KeyListener {

    private PrintWriter out;
    private Game game = new Game();
    private String id = "";

    private String ip;

    private boolean winSoundPlayed = false;

    public ClientScreen(String ip) {

        super(true);

        this.ip = ip;

        this.setLayout(null);

        //generate id
        /*for(int i = 0; i < 4; i++) {
            int num = (int)(Math.random()*9);
            id += num;
        }*/

        addKeyListener(this);

        this.setFocusable(true);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.setFont(new Font("SansSerif", Font.PLAIN, 13));

        //draw goals and centre line
        g.setColor(new Color(255, 0, 0, 60));
        g.fillRect(150, 0, 200, 75);
        g.setColor(new Color(0, 0, 255, 60));
        g.fillRect(150, 625, 200, 75);
        g.setColor(new Color(255, 255, 0, 80));
        g.fillRect(0, 350-2, 500, 4);

        for(int i = 0; i < game.getPlayers().size(); i++) {
            Player player = game.getPlayers().get(i);
            if(player.team() == 0) {
                g.setColor(Color.red);
            } else {
                g.setColor(Color.blue);
            }
            if(!player.id().equals(id)) {
                if(player.team() == 0) {
                    g.setColor(new Color(255, 0, 0, 150));
                } else {
                    g.setColor(new Color(0, 0, 255, 150));
                }
            }
            Vector2 pos = player.getPos();
            int radius = player.getRadius();
            g.fillOval((int)pos.getX()-radius, (int)pos.getY()-radius, radius*2, radius*2);
            if(player.id().equals(id)) {
                g.setColor(Color.black);
                g.drawString("You", (int)pos.getX()-radius+2, (int)pos.getY()-16);
            }
        }

        Ball ball = game.getBall();
        Vector2 ballPos = ball.getPos();
        int ballRadius = ball.getRadius();
        g.setColor(Color.black);
        g.fillOval((int)(ballPos.getX()-ballRadius), (int)(ballPos.getY()-ballRadius), (int)(ballRadius*2), (int)(ballRadius*2));


        g.setColor(new Color(230, 230, 230));
        g.fillRect(500, 0, 500, 700);
        g.setColor(Color.black);
        g.drawString("WASD - move", 510, 25);
        g.drawString("Push the ball into the goal", 510, 50);
        g.drawString("to score points", 510, 61);
        g.drawString("The ball will bounce off the border", 510, 85);
        g.drawString("Players cannot move past the border", 510, 96);

        g.setColor(Color.black);
        g.drawString("SCORE", 510, 145);
        g.setColor(Color.red);
        g.drawString("RED: "+game.getPoints2(), 510, 160);
        g.setColor(Color.blue);
        g.drawString("BLUE: "+game.getPoints1(), 510, 175);
        g.setColor(Color.black);
        g.drawString("First to "+game.getWinGoals()+" points wins", 510, 195);



        if(!game.getWinner().equals("")) {
            g.setColor(new Color(0, 0, 0, 100));
            g.fillRect(0, 0, 500, 1000);
            if(game.getWinner().equals("red")) {
                g.setColor(Color.red);
                g.setFont(new Font("SansSerif", Font.BOLD, 48));
                g.drawString("RED WINS!", 250-115, 350+18);
            } else if(game.getWinner().equals("blue")) {
                g.setColor(Color.blue);
                g.setFont(new Font("SansSerif", Font.BOLD, 48));
                g.drawString("BLUE WINS!", 250-120, 350+18);
            }
            if(!winSoundPlayed) {
                playSound("cheer");
                winSoundPlayed = true;
            }
        }



        if(game.getGoal()) {
            playSound("goal");
        }
        

        //System.out.println("klajdsklf");
        
        repaint();
    }

    public Dimension getPreferredSize() {
        return new Dimension(740 /*should be 700*/, 700);
    }

    public void poll() throws IOException {
        String hostName = ip;
        int portNumber = 1904;
        Socket serverSocket = new Socket(hostName, portNumber);
        out = new PrintWriter(serverSocket.getOutputStream(), true);
        ObjectInputStream in = new ObjectInputStream(serverSocket.getInputStream());
        BufferedReader inString = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
        id = inString.readLine();
        System.out.println(id);

        while (true) {
            try {
                //System.out.println("recieving message");
                Object objectInput = in.readObject();
                if(objectInput instanceof Game) {
                    Game updatedGame = (Game)objectInput;
                    game = updatedGame;
                }
                //System.out.println("from client game: "+game.getPlayers().get(0).getPos());
            } catch (ClassNotFoundException ex) {
                System.out.println("Error reading from server: ");
            } catch(StreamCorruptedException e) {
                e.printStackTrace();
            } catch(OptionalDataException e) {
                e.printStackTrace();
            }
        }
    }

    public void keyTyped(KeyEvent e) {
        
    }

    public void keyPressed(KeyEvent e) {
        try {
            if (out != null) {
                if(e.getKeyCode() == 87) {
                    out.println(id+"press-w");
                    //System.out.println("pressed moveup: "+id);
                } else if(e.getKeyCode() == 83) {
                    out.println(id+"press-s");
                }  else if(e.getKeyCode() == 65) {
                    out.println(id+"press-a");
                }  else if(e.getKeyCode() == 68) {
                    out.println(id+"press-d");
                }
                
                //repaint();
            }
        } catch (Exception ex) {
            System.out.println("Error writing to server: " + ex);
        }
        
    }

    public void keyReleased(KeyEvent e) {
        try {
            if (out != null) {
                if(e.getKeyCode() == 87) {
                    out.println(id+"release-w");
                    //System.out.println("pressed moveup: "+id);
                } else if(e.getKeyCode() == 83) {
                    out.println(id+"release-s");
                }  else if(e.getKeyCode() == 65) {
                    out.println(id+"release-a");
                }  else if(e.getKeyCode() == 68) {
                    out.println(id+"release-d");
                }
                
                //repaint();
            }
        } catch (Exception ex) {
            System.out.println("Error writing to server: " + ex);
        }
    }

    public void playSound(String name) {
        try {
            URL url = this.getClass().getClassLoader().getResource("sound/"+name+".wav");
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(url));
            clip.start();
        } catch (Exception exc) {
            exc.printStackTrace(System.out);
        }
    }
}