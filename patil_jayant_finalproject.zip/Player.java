import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Player implements Serializable {

    private Vector2 pos;
    private Vector2 vel = new Vector2(0, 0);
    private Vector2 acc = new Vector2(0, 0);
    private final double FRICTION = -0.15;
    private final double ACCELERATION = 0.5;

    private int radius = 15;

    private String id;

    private Set<String> directions = new HashSet<String>();

    private int team;
    
    public Player(Vector2 pos, int team, String id) {
        this.pos = pos;
        this.team = team;
        this.id = id;
    }

    public void update() {

        if(directions.contains("left")) {
            acc.set(ACCELERATION*-1, acc.getY());
        }
        if(directions.contains("right")) {
            acc.set(ACCELERATION, acc.getY());
        }
        if(directions.contains("up")) {
            acc.set(acc.getX(), ACCELERATION*-1);
        }
        if(directions.contains("down")) {
            acc.set(acc.getX(), ACCELERATION);
        }

        if(acc.getX() != 0 && acc.getY() != 0) {
            acc.set(acc.getX()*0.707, acc.getY()*0.707);
        }

        if(pos.getX() < radius || pos.getX() > 500-(radius)) {
            if(pos.getX() < radius) {
                pos.setX(radius);
            } else {
                pos.setX(500-(radius));
            }
            vel.set(vel.getX()*-1.1, vel.getY());
        }
        if(pos.getY() < radius || pos.getY() > 700-(radius)) {
            if(pos.getY() < radius) {
                pos.setY(radius);
            } else {
                pos.setY(700-(radius));
            }
            vel.set(vel.getX(), vel.getY()*-1.1);
        }

        acc = Vector2.add(acc, Vector2.multiply(vel, FRICTION));
        vel = Vector2.add(vel, acc);
        pos = Vector2.add(pos, vel);
        //System.out.println(pos);
        acc = new Vector2(0, 0);
    }

    public boolean checkCollision(Ball ball) {
        Vector2 playerPos = Vector2.add(pos, new Vector2(radius, radius));
        Vector2 ballPos = Vector2.add(ball.getPos(), new Vector2(ball.getRadius()*1.5, ball.getRadius()*1.5));
        if(Vector2.distance(playerPos, ballPos) < ball.getRadius()+radius) {
            return true;
        } else {
            return false;
        }
    }

    public Vector2 getPos() {
        return pos;
    }

    public Vector2 getVel() {
        return vel;
    }

    public void setAcc(Vector2 acc) {
        this.acc = acc;
    }

    public void setXAcc(double x) {
        acc.set(x, acc.getY());
    }

    public void setYAcc(double y) {
        acc.set(y, acc.getY());
    }

    public String id() {
        return id;
    }

    public int team() {
        return team;
    }

    public int getRadius() {
        return radius;
    }

    public void addDirection(String dir) {
        directions.add(dir);
    }

    public void removeDirection(String dir) {
        directions.remove(dir);
    }

    public void roundAll() {
        acc = Vector2.round(acc, 3);
        vel = Vector2.round(vel, 3);
        pos = Vector2.round(pos, 3);
    }

}
