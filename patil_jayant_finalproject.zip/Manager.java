import java.util.*;
import java.io.*;
import java.net.*;

public class Manager {

    private DLList < ServerThread > threads;
    private Game game;

    public Manager() {
        threads = new DLList < ServerThread > ();
        game = new Game();
    }

    public void add(Socket socket) {
        //generate id
        String id = "";
        for(int i = 0; i < 8; i++) {
            int num = (int)(Math.random()*9);
            id += num;
        }

        ServerThread serverThread = new ServerThread(this, socket, id);
        threads.add(serverThread);
        Thread newThread = new Thread(serverThread);
        newThread.start();

        int playersNum = threads.size();
        int team = playersNum%2;
        game.addPlayer(new Player(new Vector2(100+(playersNum*50), 150+(team*400)), team, id));
    }

    public void updateClients() {
       // System.out.println("distributing message: " + threads);
        //game.update();
        if(threads.size() != 0) {
            for(int i = 0; i < threads.size(); i++) {
                ServerThread thread = threads.get(i);
                thread.updateGame(game);
            }
        }
    }

    public void doGameUpdate() {
        game.update();
    }
    
    public Game getGame() {
        return game;
    }

    public void setGame(Game g) {
        game = g;
        //System.out.println("manager: "+game.getPlayers().get(0).getPos());
    }
}